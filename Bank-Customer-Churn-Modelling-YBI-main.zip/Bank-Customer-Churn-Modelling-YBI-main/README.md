# Bank-Customer-Churn-Modelling

To predict whether the customer will stay or leave the bank
